﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Work
{
    public class While
    {
        public bool While4(float n)
        {
            while (n>1)
            {
                n /= 3;
            }
            return 
                n == 1 ? true : false;
        }
        public int While8(int n)
        {
            int k = 1;
            while (Math.Pow(k + 1, 2) <= n)
            {
                k++;
            }
            return k;
        }
        public bool While20(int n)
        {
            int Chislo = 0;
            while (Chislo != 2 && n > 2)
            {
                Chislo = n % 10;
                n = n / 10;
            }
            return Chislo == 2 ? true : false;
        }
        public bool While24(int Chislo)
        {
            int f1 = 1;
            int f2 = 1;
            int f3 = 2;
            while (Chislo != f3 && f2 + f1 > 0)
            {
                f3 = f2 + f1;
                f1 = f2;
                f2 = f3;
            }
            return Chislo == f3 ? true : false;
        }
        public int While28(int n)
        {
            int a1 = 0;
            int a2 = 1;
            int a3 = 0;
            int Chislo = 1;
            while (n != a3 && a2 + a1 > 0)
            {
                a3 = a2 + a1;
                a1 = a2;
                a2 = a3;
                Chislo++;
            }
            return Chislo;
        }
    }
}
