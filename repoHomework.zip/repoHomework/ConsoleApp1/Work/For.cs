﻿using System;

namespace Work
{
    public class For
    {
        public void For4(int sweet)
        {
            for (int i = 1; i < 11; i++)
            {
                Console.Write((i * sweet) + " ");
            }
        }
        public int For8(int b)
        {
            int result = 1;
            for (int a = 1; a <= b; a++)
            {
                result *= a;
            }
            return result;
        }
        public void For12(float n)
        {
            float result = 1f;
            for (float a = 1.1f; Math.Abs(a) <= n; a += 0.1f)
            {
                result *= a;
            }
            Console.WriteLine(Math.Round(result, 2));
        }
        public void For16(int n,int num)
        {
            for (int i = 1; i <= n; i++)
            {
                int result = (int)Math.Pow(num, i);
                Console.Write(result + " ");
            }
        }
        public int For20(int n)
        {
            int b = 1;
            int result = 0;
            for (int i = 1; i <= n; i++)
            {
                b *= i;
                result += b;
            }
            return result;
        }
        public void For24(int n)
        {
            int b = 1;
            float x = 2f;
            float result = 1f;
            int k = 1;
            for (int i = 1; i <= n; i++)
            {
                b *= k;
                k++;
                b *= k;
                result -= (float)Math.Pow(x, i * 2) * -1f / b;
            }
            Console.WriteLine(Math.Round(result, 3));
        }
        public void For32(int a)
        {
            float Chislo = 1f;
            float k = 3f;
            for (int i = 0; i < a; i++)
            {
                Chislo = (Chislo + 1) / k;
                Console.Write(Chislo + " ");
            }
        }
        public void For40(int a)
        {
            int b = a + 3;
            for (int num = 0; num <= b - a; num++)
                for (int i = 0; i <= num; i++)
                {
                    Console.Write(" " + (a + num));
                }
        }
    }
}
